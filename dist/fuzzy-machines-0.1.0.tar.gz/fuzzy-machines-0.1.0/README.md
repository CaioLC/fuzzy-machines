# fuzzy-machines
A generic approach to fuzzy logic inference systems in python.

# Documentation:
https://fuzzy-machines.readthedocs.io/en/master/
