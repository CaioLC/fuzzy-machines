Lumache
=======

**Fuzzy Machines** (/lu'make/) is a Python library for general fuzzy logic mathematics. It is inspired by Matlab Fuzzy Logic tutorials.


.. ### BUILDING FROM SOURCE
.. 1. Clone this repo
.. 2. run `pip install -r requirements_dev.txt`
.. 3. run `python setup.py sdist bdist_wheel`